module.exports = {
  verbose: true,
  testMatch: ['src/**/*spec.ts']
};
