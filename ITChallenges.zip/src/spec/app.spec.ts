describe('Path Editor', () => {
  it('should init path editor', () => {})
})
