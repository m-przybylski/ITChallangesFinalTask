describe('Path', () => {
  it('should scale by given factor', () => {})
})
