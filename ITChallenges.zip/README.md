## BUILD:

yarn i
yarn build

## RUN - DEV MODE

yarn i
yarn start

## BUILD OUTPUT

/dist/index.html